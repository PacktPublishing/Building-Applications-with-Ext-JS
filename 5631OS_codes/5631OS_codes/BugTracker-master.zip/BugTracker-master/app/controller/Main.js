Ext.define('BugTracker.controller.Main', {
    extend: 'Ext.app.Controller'
});
