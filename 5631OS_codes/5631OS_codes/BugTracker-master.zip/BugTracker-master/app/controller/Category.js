Ext.define('BugTracker.controller.Category', {
	extend: 'Ext.app.Controller',
	init: function() {
	}
});