Ext.define('BugTracker.controller.admin.AbstractMasterData', {
	extend: 'Ext.app.Controller'
});