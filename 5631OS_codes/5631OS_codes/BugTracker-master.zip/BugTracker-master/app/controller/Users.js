Ext.define('BugTracker.controller.Users', {
    extend: 'Ext.app.Controller',
    views: ['UserGrid', 'UserForm']

});