
	Ext.define('BugTracker.utils.Format', {
		addDays: function(i) { return i + ' days' }
	})