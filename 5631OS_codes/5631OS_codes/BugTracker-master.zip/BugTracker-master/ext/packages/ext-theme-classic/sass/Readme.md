# ext-theme-classic/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    ext-theme-classic/sass/etc
    ext-theme-classic/sass/src
    ext-theme-classic/sass/var
